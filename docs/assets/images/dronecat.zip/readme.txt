fuelfonts type foundry Shareware Fonts Readme!

COPYRIGHT NOTICES
All Fonts � Claes K�llarsson /
fuelfonts type foundry. All Rights Reserved.

THESE ARE SHAREWARE FONTS!
NOT FREEWARE!

For the latest version of this readme file, please
visit www.fuelfonts.com/readme/

PERSONAL USE
These fonts are SHAREWARE, that means you can use them
for free for 30 days and after that I hope that you are
kind enough to pay the 10 US$ shareware fee if you want
to use this font more. I won't chase you with a blow
torch but if you enjoy my fonts support my work so that
I can make more shareware fonts!

COMMERCIAL USE
If you plan on using one of my shareware fonts in a
commercial project then it's not enough with just 10
us$, the fee for using one of my shareware fonts in
a commercial project is 100 US$. Contact me at my email
address (grizzly@fucker.com) if you want to use one of
my shareware fonts in a commercial project.

(commercial project = advertisements, cd-booklets,
corporate websites, movie posters, etc)

Also, the license for commercial use is for 2 CPUs
and one printer, you'll get a license file when you
pay me. the extra charge if you have to use it on
more computers/printers are 15 us$ per CPU or Printer.

If you like my shareware fonts, please send 10 us$
(or the 100 us$ commercial fee), and please send
CASH ONLY (10/100 dollar bills) because I can't
cash foreign checks. Send it to:

 fuelfonts type foundry
 c/o Claes Kallarsson
 Skimmelvagen 7
 S-85752 Sundsvall
 S W E D E N

REDISTRIBUTING FUELFONTS
If you want to re-distribute my fonts on your website I
have three rules I'd like you to follow:

1. Always include the text-files (like this one).

2. Link to my site so the people who download my fonts
   know where they can get more of my fonts.

3. Never re-distribute all fuelfonts, only my site can
   give away all the fonts in the fuelfonts collection,
   just give away 5-6 fonts on your site and let people
   visit my site if they want more.

And please if you can, send me an email and tell me that
you are giving away my fonts! It would be much appreciated.
my email address is grizzly@fucker.com

hope you'll enjoy my fonts,
			     Claes

url:
 http://www.fuelfonts.com
 http://www.chank.com/fuelfonts

email:
 grizzly@fucker.com

Copyright � Claes K�llarsson / fuelfonts type foundry.
All Rights Reserved.